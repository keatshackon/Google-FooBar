# Questionnaire
Upon completion of the third level, Foo Bar asked if I wanted to send information to a Google recruiter. Here are the questions:

### [#1] The code is strong with this one. Share solutions with a Google recruiter?

- [Y]es [N]o [A]sk me later: Y

### Please provide the following information. By providing the information you agree to the Terms & Conditions.

- [#2] First name:
- [#3] Last name:
- [#4] Email:
- [#5] Country:
- [#6] Phone number:
- [#7] Other helpful links (optional):

### Are the above details correct?

- [Y]es or [N]o: Y  

### Submitting your response...
### Response saved.

### [#1] Enter current status to be routed to optimal recruiter:

1. Currently in high school
2. Currently pursuing a degree
3. Will complete degree within 1 year
4. Professional
5. Other
- Enter 1-5:

### Are the above details correct?

- [Y]es or [N]o: Y

### Submitting your response...
###  Your progress will be reviewed.
### But the challenge is not over yet.